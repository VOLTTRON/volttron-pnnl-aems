Files placed in this directory will get seeded at server start.
JSON should conform to: `./app/src/services/types/Seeder`

> Note: After creating or updating static users the user seed file should be deleted to prevent password exposure.
