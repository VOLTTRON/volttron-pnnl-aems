-- AlterTable
ALTER TABLE "Units" ALTER COLUMN "heatPumpBackup" SET DEFAULT 0;
