import NotFound from "./NotFound";

const Root = () => {
  return <NotFound />;
};

export default Root;
