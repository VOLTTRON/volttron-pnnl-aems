import Error from "./Error";

const Root = () => {
  return <Error />;
};

export default Root;
