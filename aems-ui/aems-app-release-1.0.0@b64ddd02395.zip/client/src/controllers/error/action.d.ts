export function selectErrorTokens(state: any): any;
export function clearError(errorKey: any): {};
