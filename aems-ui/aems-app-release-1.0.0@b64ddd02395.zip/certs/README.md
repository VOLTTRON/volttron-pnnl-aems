Place TLS certificates in here and update the `certs-traefik.yml` file with the file paths. Multiple certificate pairs can be added to the Traefik configuration file as needed.
