1. Added pre-commit-config hooks
2. Yapf formatting for code (see: https://github.com/google/yapf#knobs for customizations)
 a. Run using yapf -r --in-place --style .yapf.format.txt .

Using pre-commit
1. Install pip install pre-commit
2. Run pre-commit install (sets up pre-commit hooks to run with the changes.)
