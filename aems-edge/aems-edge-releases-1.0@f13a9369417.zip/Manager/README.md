For Schneider thermostat need to set: 
       "Setpoint Function" - SetpointFunction =  [multiStateValue 58] = 1 to "detach" 
       "Economizer Configuration" - HasEconomizer [multiStateValue 72] = [1=No economizer, 2=Has economizer] [configuration screen 5/11]
       "Mechanical Cooling Allowed" - MechanicalCoolingDuringEconomizing [multiStateValue 79] = [1=No economizer, 2=Has economizer] [configuration screen 5/11]
       "Application" -  Application [multiStateValue 119] = [1=RTU, 2=HPU] [configuration screen 8/11]
